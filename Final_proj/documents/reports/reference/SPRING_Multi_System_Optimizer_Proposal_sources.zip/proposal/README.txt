Editable proposal sources
=========================

Scope: optimizing neural wavefunctions for strongly correlated quantum systems.
Ising is the entry-level benchmark; Hubbard or FQHE is the advanced extension.
Current Ising/FQHE data are preliminary examples. Hubbard work is proposed.

The PDF has two main proposal pages and two appendix pages: the shared VMC/
SPRING workflow, followed by the available ED database and retained NN examples.
Eight primary-paper links are included. The database introduction reports the
present sizes: 11 Hamiltonian instances, 12,085 configuration rows counted per
instance, per-system decoded input shapes, and saved neural diagnostic sizes.
The detailed size inventory and source hashes are in proposal_verified_data.json.

Compile this source package with its bundled frozen figure PDFs:
  latexmk -pdf -interaction=nonstopmode -halt-on-error SPRING_Multi_System_Optimizer_Proposal.tex

The figure generator runs inside the original Final_proj repository, using
its ED/NN records. It requires NumPy and Matplotlib; hashes are recorded in
proposal_verified_data.json. The bundled figures allow LaTeX compilation
without Python, training or ED calculations.

Revised 23 October 2026. No Hubbard benchmark or new training is claimed.

The current Git checkout uses SPRING_Ising_test and SPRING_Haldane_FQHE.
Contributor handle: PassengerAn. Build the two-page outline from the same TeX
source by defining OutlineOnly before inputting the proposal file.
